﻿/* Copyright (c) $year$ $companyname$.  All rights reserved. */

namespace $safeprojectname$.Enums
{
    public enum UiMode
    {
        New = 0,
        Add = 1,
        Save = 2,
        None = 3
    }
}