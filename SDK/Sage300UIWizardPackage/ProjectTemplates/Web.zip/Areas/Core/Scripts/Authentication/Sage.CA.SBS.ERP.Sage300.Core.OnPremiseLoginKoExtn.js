﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

"use strict";
