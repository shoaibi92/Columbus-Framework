﻿/* Copyright (c) $year$ $companyname$.  All rights reserved. */

namespace $companynamespace$.Web.Areas.$applicationid$.Constants
{
    /// <summary>
    /// Constants used across $applicationid$ module
    /// </summary>
    public static class Constants
    {
        #region Finder
       
        #endregion

        #region Export/Import
      
        #endregion

        public const string AppId = "$applicationid$";

        #region Grid Preferences
        
        #endregion
        
        #region Cache Key

        #endregion
    }
}