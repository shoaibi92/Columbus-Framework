/* Copyright (c) $year$ $companyname$.  All rights reserved. */

namespace $companynamespace$.$applicationid$.BusinessRepository
{
    public class Security
    {
        /// <summary>
        /// $applicationid$ Export
        /// </summary>
        public const string $applicationid$Export = "$applicationid$Export";
 
        /// <summary>
        /// $applicationid$ Import
        /// </summary>
        public const string $applicationid$Import = "$applicationid$Import";
 
        // TODO: Add other Security Resource strings here
 
    }
}

